//basic operation of one-way-list

#ifndef FINAL_TASK_LIST_H
#define FINAL_TASK_LIST_H

#include "dataset.h"

void InitList(ppStudent head);  //initialize list
void Append(ppStudent head, int number, int subject);  //add a new element to the end of th list
void TraverseList(ppStudent head);  //show all elements of the list
void ClearList(ppStudent node);  //destroy list, which is used at the end of file

#endif //FINAL_TASK_LIST_H
